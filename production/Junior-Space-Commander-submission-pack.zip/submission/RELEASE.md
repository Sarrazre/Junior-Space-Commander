# Public release — 15 November 2026

Play: https://junior-space-commander.sentientstudios.chatgpt.site/

Source download: https://junior-space-commander.sentientstudios.chatgpt.site/source.zip

License: https://junior-space-commander.sentientstudios.chatgpt.site/LICENSE.txt

## Publication provenance

- Sites project: appgprj_6af99adac2348191831cde8c2c9f5b5d
- Published version: 3
- Source commit: 74967c8618bb4975b844fbfe25a13e922af0ab9c
- Saved version: appgprj_6af99adac2348191831cde8c2c9f5b5d~appgver_255d1282b9fc8191b34638efcb84cb9f
- Production deployment: appgdep_6af99e0eed8481918c507476d06e3016
- Deployment result: succeeded; audience: public.
- Separate publishing checkout: /Users/wess/Documents/nasa/sites/junior-space-commander
- The original GitHub repository was not pushed or replaced.

## Automated release checks

- All 42 tests passed, including campaign checkpoint restoration, first-flight flow, resource guidance, NASA fallback, room states, clocks, quizzes and narration.
- The balance simulation completed all 96 decision paths in each of six scenarios (two difficulties and three play styles).
- Production build passed. The final rover-only CSS fix was rebuilt and packaged after the successful tests; it does not alter campaign logic.
- All 310 prepared voice clips were present and their hashes matched the voice manifest.

## Hosted checks

- First visit starts the intro; title and illustrated mode selection load.
- Five-step walkthrough points to resources, crew and objective, routes Max to Command and opens the terminal.
- Sol 1 decision changes resources and unlocks science. The full three-sample rock experiment completes and awards 10 points.
- Reload and Continue restore the decision, resources and 10 science points. Intro does not replay over a returning save.
- End-sol confirmation and summary lead to Sol 2. Its decision unlocks the rover mission.
- The production 3D rover loads; keyboard driving reduces distance to the first site. Prepared spoken instructions reach the speaking state.
- Rover clock overlap was repaired and verified in version 3: the clock is hidden during driving, the exit button is fully visible and usable, and returning to the base restores the clock. The panorama toggle also works on the hosted release.
- The final checked browser session reported no console errors. Evidence: hosted-base.jpg and hosted-rover.jpg.
- Anonymous browser-style GET requests succeed for the HTML, source ZIP, license, credits, video, voice manifest, optional ONNX model and WASM runtime. Large files were checked for access and content type; full optional model inference was not rerun on the hosted origin.
- Sites reports public access. No owner login is required for ordinary browser-style HTTP requests.

## Limits and handoff

Hosted smoke tests cover the first science mission and rover launch/driving, not a manual replay of all five sols or every minigame. Automated checks cover campaign progression. No second physical device was available for this release check; earlier phone-sized browser layout checks passed.

Saves stay in the browser/origin where played. Localhost progress is not automatically transferred. Prepared narration works independently of the optional personalized voice download. NASA live data has a labelled historical fallback.

Team/event details are intentionally deferred. The official NASA project form has not been submitted. Use SUBMISSION.md, THIRD-PARTY.md and DEMO-SCRIPT.md to finish that step through the registered team's Project tab.
