# Junior Space Commander release source

Team-authored code and documentation: MIT. Other components and agency materials retain their terms.

Large media and voice files are available from the public release. With Node 20+:

1. node scripts/fetch-release-assets.mjs
2. npm ci
3. npm run dev (or npm test && npm run build)

Play: https://junior-space-commander.sentientstudios.chatgpt.site/
Upstream: https://github.com/Sarrazre/Junior-Space-Commander/
